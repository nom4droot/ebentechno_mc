global.pitchAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle = 0.0;
global.yawAngleO = 0.0;
local l = (context.bl and 1) or -1
local player = context.player
local item = context.item
local matrices = context.matrices
local mainHand = context.mainHand


local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

local buckets = {
    "minecraft:bucket",
    "minecraft:water_bucket",
    "minecraft:lava_bucket",
    "minecraft:powder_snow_bucket",
    "minecraft:cod_bucket",
    "minecraft:salmon_bucket",
    "minecraft:tropical_fish_bucket",
    "minecraft:tadpole_bucket"
    
    
}

for _, id in ipairs(buckets) do
    if I:isOf(item, Items:get(id))
     then
        M:moveY(matrices, 0.4)
        M:moveZ(matrices, -0.05)
        return
    end
end

if I:isOf(item, Items:get("minecraft:milk_bucket")) and not P:isUsingItem(player) then
        M:moveY(matrices, 0.4)
        M:moveZ(matrices, -0.05)
        
end
