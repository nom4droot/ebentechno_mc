# About

Oct-Path is a Minecraft shaderpack based on Octray Rewrite, an open source ray tracing shader developed by Bruce KnowsHow.
"Octray Rewrite" is an innovative ray tracing shader that supports unlimited render distance, i.e., raytracing the entire render distance (64x chunks, 384 height), and allows casting long distance rays at high speeds by implementing an Octree-like acceleration structure for ray tracing.
While "Octray Rewrite" has an excellent ray tracing mechanism, it was incomplete because it omitted drawing entities and omitted translucent processing including water, and so on. Therefore, Oct-Path was born to take advantages of this shader while not interfering with Minecraft gameplay.


# Requirements

 -OptiFine 1.16.5 or newer (Iris is not supported)
 -Graphics card supporting OpenGL 4.0 or later (newer ones are preferable)


# Installation

As a precondition, OptiFine is installed
-Minecraft > Video Settings... > Shaders... > Shaders Folder
 so the shaderpacks folder is opened.
-Place the downloaded Oct-Path zip file in the shaderpacks folder. (No need to unzip the zip file)
-Select Oct-Path from the Shaders list.


# Special Thanks

Special thanks to BruceKnowsHow who developed "Octray Rewrite".

"Octray Rewrite" has been declared open source by the author, and moreover, BruceKnowsHow has also given his approval when I released Oct-Path, saying "Yep, you are free to release it".
