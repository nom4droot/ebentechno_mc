ivec4 bounds[16] = ivec4[16](
    ivec4( PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(1.0, 0.5, 1.0)) ),      // 3:slab bottom
    ivec4( PackAABB(vec3(0.0, 0.5, 0.0), vec3(1.0, 1.0, 1.0)),        // 4:slab top
           0,                                                         // 5:
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(1.0, 1.0/8.0, 1.0)),    // 6:snow:layers=1
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(1.0, 2.0/8.0, 1.0)) ),  // 7:snow:layers=2
    ivec4( PackAABB(vec3(0.0, 0.0, 0.0), vec3(1.0, 3.0/8.0, 1.0)),    // 8:snow:layers=3
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(1.0, 4.0/8.0, 1.0)),    // 9:snow:layers=4
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(1.0, 5.0/8.0, 1.0)),    // 10:snow:layers=5
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(1.0, 6.0/8.0, 1.0)) ),  // 11:snow:layers=6
    ivec4( PackAABB(vec3(0.0, 0.0, 0.0), vec3(1.0, 7.0/8.0, 1.0)),    // 12:snow:layers=7
           PackAABB(vec3(1.0/16.0, 0.0, 1.0/16.0), vec3(15.0/16.0, 1.0/16.0, 15.0 / 16.0)),  // 13:pressure plate
           PackAABB(vec3(5.0/16.0,  6.0/16.0, 14.0/16.0),     vec3(11.0/16.0, 10.0/16.0, 16.0 / 16.0)),        // 14:button shapes north
           PackAABB(vec3(5.0/16.0,  6.0/16.0,  0.0/16.0),     vec3(11.0/16.0, 10.0/16.0,  2.0 / 16.0)) ),      // 15:button shapes south
    ivec4( PackAABB(vec3(5.0/16.0,  6.0/16.0,  0.0/16.0).zyx, vec3(11.0/16.0, 10.0/16.0,  2.0 / 16.0).zyx),    // 16:button shapes east
           PackAABB(vec3(5.0/16.0,  6.0/16.0, 14.0/16.0).zyx, vec3(11.0/16.0, 10.0/16.0, 16.0 / 16.0).zyx),    // 17:button shapes west
           PackAABB(vec3(5.0/16.0,  0.0/16.0,  6.0/16.0),     vec3(11.0/16.0,  2.0/16.0, 10.0 / 16.0)),        // 18:button shapes bottom north/south
           PackAABB(vec3(5.0/16.0,  0.0/16.0,  6.0/16.0).zyx, vec3(11.0/16.0,  2.0/16.0, 10.0 / 16.0).zyx) ),  // 19:button shapes bottom east/west
    ivec4( PackAABB(vec3(5.0/16.0, 14.0/16.0,  6.0/16.0),     vec3(11.0/16.0, 16.0/16.0, 10.0 / 16.0)),        // 20:button shapes top north/south
           PackAABB(vec3(5.0/16.0, 14.0/16.0,  6.0/16.0).zyx, vec3(11.0/16.0, 16.0/16.0, 10.0 / 16.0).zyx),    // 21:button shapes top east/west
           PackAABB(vec3(7.0/16.0, 0.0, 7.0/16.0), vec3(9.0/16.0, 10.0/16.0, 9.0/16.0)),  // 22:redstone_torch:lit=false
           PackAABB(vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3( 3.0/16.0, 16.0/16.0, 16.0/16.0)) ),  // 23:door east (upper/lower)
    ivec4( PackAABB(vec3(13.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0)),    // 24:door west (upper/lower)
           PackAABB(vec3( 0.0/16.0,  0.0/16.0, 13.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0)),    // 25:door north (upper/lower)
           PackAABB(vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0,  3.0/16.0)),    // 26:door south (upper/lower)
           0                                                                                      ),  // 27:
    ivec4( 0,                                                                                         // 28:
           0,                                                                                         // 29:
           0,                                                                                         // 30:
           PackAABB(vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  3.0/16.0, 16.0/16.0)) ),  // 31:trapdoor bottom
    ivec4( PackAABB(vec3( 0.0/16.0, 13.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0)),    // 32:trapdoor top
           PackAABB(vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3( 3.0/16.0, 16.0/16.0, 16.0/16.0)),    // 33:trapdoor east
           PackAABB(vec3(13.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0)),    // 34:trapdoor west
           PackAABB(vec3( 0.0/16.0,  0.0/16.0, 13.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0)) ),  // 35:trapdoor north
    ivec4( PackAABB(vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0,  3.0/16.0)),    // 36:trapdoor south
           PackAABB(vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  3.0/16.0, 16.0/16.0)),    // 37:trapdoor(fix) bottom
           PackAABB(vec3( 0.0/16.0, 13.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0)),    // 38:trapdoor(fix) top
           PackAABB(vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3( 3.0/16.0, 16.0/16.0, 16.0/16.0)) ),  // 39:trapdoor(fix) east
    ivec4( PackAABB(vec3(13.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0)),    // 40:trapdoor(fix) west
           PackAABB(vec3( 0.0/16.0,  0.0/16.0, 13.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0)),    // 41:trapdoor(fix) north
           PackAABB(vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0,  3.0/16.0)),    // 42:trapdoor(fix) south
            0), // 43
    ivec4(0, 0, 0, 0), // 44
    ivec4(0, 0, 0, 0), // 48
    ivec4(0, 0, 0, 0), // 52
    ivec4(0, 0, 0, 0), // 56
    ivec4(0, 0, 0, 0)  // 60
);

ivec4 bounds_emissive[16] = ivec4[16](
    ivec4( PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)), // 128
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)) ),
    ivec4( PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)), // 132
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)) ),
    ivec4( PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)), // 136
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)) ),
    ivec4( PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)), // 140
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)) ),
    ivec4( PackAABB(vec3(7.0/16.0, 0.0, 7.0/16.0), vec3(9.0/16.0, 10.0/16.0, 9.0/16.0)), // 144:redstone_torch:lit=true
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)) ),
    ivec4(0, 0, 0, 0), // 148
    ivec4(0, 0, 0, 0), // 152
    ivec4(0, 0, 0, 0), // 156
    ivec4( PackAABB(vec3(7.0/16.0, 0.0, 7.0/16.0), vec3(9.0/16.0, 10.0/16.0, 9.0/16.0)), // 160:soul_torch
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)) ),
    ivec4(0, 0, 0, 0), // 164
    ivec4(0, 0, 0, 0), // 168
    ivec4(0, 0,        // 172
                0, 0),
    ivec4( PackAABB(vec3(7.0/16.0, 0.0, 7.0/16.0), vec3(9.0/16.0, 10.0/16.0, 9.0/16.0)), // 176:torch
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)),
           PackAABB(vec3(0.0, 0.0, 0.0), vec3(0.0, 0.0, 0.0)) ),
    ivec4(0, 0, 0, 0), // 180
    ivec4(0, 0, 0, 0), // 184
    ivec4(0, 0, 0, 0)  // 188
);

int getBounds(int blockID) {  // precondition: (blockID >= 3 && blockID <= 63) || (blockID >= 128 && blockID <= 191)
    /*
    int packedBounds;
    if (blockID >= 3 && blockID <= 63) {
        packedBounds = bounds[blockID/4][blockID%4];
    } else if (blockID >= 128 && blockID <= 191) {
        blockID -= 128;
        packedBounds = bounds_emissive[blockID/4][blockID%4];
    }
    */
    int packedBounds = (blockID >= 3 && blockID <= 63) ? bounds[blockID/4][blockID%4] : 0;
        packedBounds = (blockID >= 128 && blockID <= 191) ? bounds_emissive[(blockID - 128)/4][(blockID - 128)%4] : packedBounds;
    return packedBounds;
}

const vec3[24][6] stairBounds = vec3[24][6](
    vec3[6]( vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),  // 1000:stairs bottom north straight
             vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0,  8.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),  // 1001:stairs bottom south straight
             vec3( 0.0/16.0,  8.0/16.0,  8.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),  // 1002:stairs bottom east straight
             vec3( 8.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),  // 1003:stairs bottom west straight
             vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3( 8.0/16.0, 16.0/16.0, 16.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),  // 1004:stairs bottom (north + inner_left)/(west + inner_right)
             vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0,  8.0/16.0),
             vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3( 8.0/16.0, 16.0/16.0, 16.0/16.0) ),
    vec3[6]( vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),  // 1005:stairs bottom (north + inner_right)/(east + inner_left)
             vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0,  8.0/16.0),
             vec3( 8.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0) ),
    vec3[6]( vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),  // 1004:stairs bottom (south + inner_left)/(east + inner_right)
             vec3( 0.0/16.0,  8.0/16.0,  8.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),
             vec3( 8.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0) ),
    vec3[6]( vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),  // 1005:stairs bottom (south + inner_right)/(west + inner_left)
             vec3( 0.0/16.0,  8.0/16.0,  8.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),
             vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3( 8.0/16.0, 16.0/16.0, 16.0/16.0) ),
    vec3[6]( vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),  // 1008:stairs bottom (north + outer_left)/(west + outer_right)
             vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3( 8.0/16.0, 16.0/16.0,  8.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),  // 1009:stairs bottom (north + outer_right)/(east + outer_left)
             vec3( 8.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0,  8.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),  // 1010:stairs bottom (south + outer_left)/(east + outer_right)
             vec3( 8.0/16.0,  8.0/16.0,  8.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),  // 1011:stairs bottom (south + outer_right)/(west + outer_left)
             vec3( 0.0/16.0,  8.0/16.0,  8.0/16.0), vec3( 8.0/16.0, 16.0/16.0, 16.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),  // 1012:stairs top north straight
             vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0,  8.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),  // 1013:stairs top south straight
             vec3( 0.0/16.0,  0.0/16.0,  8.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),  // 1014:stairs top east straight
             vec3( 8.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),  // 1015:stairs top west straight
             vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3( 8.0/16.0,  8.0/16.0, 16.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),  // 1016:stairs top (north + inner_left)/(west + inner_right)
             vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0,  8.0/16.0),
             vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3( 8.0/16.0,  8.0/16.0, 16.0/16.0) ),
    vec3[6]( vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),  // 1017:stairs top (north + inner_right)/(east + inner_left)
             vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0,  8.0/16.0),
             vec3( 8.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0) ),
    vec3[6]( vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),  // 1018:stairs top (south + inner_left)/(east + inner_right)
             vec3( 0.0/16.0,  0.0/16.0,  8.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),
             vec3( 8.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0) ),
    vec3[6]( vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),  // 1019:stairs top (south + inner_right)/(west + inner_left)
             vec3( 0.0/16.0,  0.0/16.0,  8.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),
             vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3( 8.0/16.0,  8.0/16.0, 16.0/16.0) ),
    vec3[6]( vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),  // 1020:stairs bottom (north + outer_left)/(west + outer_right)
             vec3( 0.0/16.0,  0.0/16.0,  0.0/16.0), vec3( 8.0/16.0,  8.0/16.0,  8.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),  // 1021:stairs bottom (north + outer_right)/(east + outer_left)
             vec3( 8.0/16.0,  0.0/16.0,  0.0/16.0), vec3(16.0/16.0,  8.0/16.0,  8.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),  // 1022:stairs bottom (south + outer_left)/(east + outer_right)
             vec3( 8.0/16.0,  0.0/16.0,  8.0/16.0), vec3(16.0/16.0,  8.0/16.0, 16.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) ),
    vec3[6]( vec3( 0.0/16.0,  8.0/16.0,  0.0/16.0), vec3(16.0/16.0, 16.0/16.0, 16.0/16.0),  // 1023:stairs bottom (south + outer_right)/(west + outer_left)
             vec3( 0.0/16.0,  0.0/16.0,  8.0/16.0), vec3( 8.0/16.0,  8.0/16.0, 16.0/16.0),
             vec3(     -1.0,      -1.0,      -1.0), vec3(     -1.0,      -1.0,      -1.0) )
);

bool IntersectAABBparts(vec3 pos, vec3 dir, AABB aabb, out vec3 plane, out float dist) {
    if(any(lessThan(aabb.minBounds, vec3(0.0)))) return false;
    vec3 minBoundsDist = (aabb.minBounds + 1e-3 - pos) / dir;  // apply slight bias in order not to protrude from block.
    vec3 maxBoundsDist = (aabb.maxBounds - 1e-3 - pos) / dir;
    
    vec3 minDists = min(minBoundsDist, maxBoundsDist);
    vec3 maxDists = intBitsToFloat(floatBitsToInt(minBoundsDist) ^ floatBitsToInt(maxBoundsDist) ^ floatBitsToInt(minDists));
    
    ivec3 a = floatBitsToInt(minDists - maxDists.yzx);
    ivec3 b = floatBitsToInt(minDists - maxDists.zxy);
    a = a & b;
    if ((a.x & a.y & a.z) >= 0)
        return false;
    
    vec3 positiveDir = step(0.0, dir);
    vec3 dists = mix(maxBoundsDist, minBoundsDist, positiveDir);
    
    MinComp(-dists, plane);
         dists = max(vec3(0.0), dists);
    
    if (dists.x > dists.y) {
        if (dists.x > dists.z) {
            dist = dists.x;
        } else {
            dist = dists.z;
        }
    } else if (dists.y > dists.z) {
        dist = dists.y;
    } else {
        dist = dists.z;
    }
    
    return dist > 0.0;
}

bool SimpleIntersectStair(int blockID, inout vec3 pos, vec3 dir) {
    int stairID = blockID - 1000;  // precondition: blockID >= 1000 && blockID <= 1023
    AABB parts1 = AABB(stairBounds[stairID][0], stairBounds[stairID][1]);
    AABB parts2 = AABB(stairBounds[stairID][2], stairBounds[stairID][3]);
    AABB parts3 = AABB(stairBounds[stairID][4], stairBounds[stairID][5]);
    bool hit1 = SimpleIntersectAABB(pos, dir, parts1);
    bool hit2 = SimpleIntersectAABB(pos, dir, parts2);
    bool hit3 = SimpleIntersectAABB(pos, dir, parts3);
    return hit1 || hit2 || hit3;
}

struct IntersectOutput {
    bool  hit;
    float dist;
    vec3  plane;
};

bool IntersectStair(int blockID, inout vec3 pos, vec3 dir, out vec3 plane) {
    int stairID = blockID - 1000;  // precondition: blockID >= 1000 && blockID <= 1023
    AABB parts1 = AABB(stairBounds[stairID][0], stairBounds[stairID][1]);
    AABB parts2 = AABB(stairBounds[stairID][2], stairBounds[stairID][3]);
    AABB parts3 = AABB(stairBounds[stairID][4], stairBounds[stairID][5]);
    IntersectOutput result1, result2, result3;
    result1.hit = IntersectAABBparts(pos, dir, parts1, result1.plane, result1.dist);
    result2.hit = IntersectAABBparts(pos, dir, parts2, result2.plane, result2.dist);
    result3.hit = IntersectAABBparts(pos, dir, parts3, result3.plane, result3.dist);
    
    IntersectOutput result = IntersectOutput(false, 0.0, vec3(0.0));
    result = (result1.hit) ? result1 : result;
    result = (result2.hit && (!result.hit || result2.dist < result.dist)) ? result2 : result;
    result = (result3.hit && (!result.hit || result3.dist < result.dist)) ? result3 : result;

    pos = (result.hit) ? pos + dir * result.dist : pos;
    plane = result.plane;
    return result.hit;
}

float IntersectPlane(vec3 pos, vec3 dir, vec3 normal, out vec3 plane) {
    vec3 point = vec3(0.5);
    plane = -normal * sign(dot(normal, dir));
    return clamp(dot(point - pos, normal) / dot(dir, normal), -1.0, 9999000.0);
}

bool IntersectF(int blockID, inout vec3 pos, vec3 dir, out vec3 plane) {
    vec3 planeNormal = blockID == 192 ? vec3(0.0, 0.0, 0.5) : vec3(0.5, 0.0, 0.0);
    float dist = IntersectPlane(pos, dir, normalize(planeNormal), plane);

    vec3 newpos = pos + dir * dist;

    bool intersect = dist > 0.0 && newpos == clamp(newpos, 0.0, 1.0);  // if newpos is outside this range, it is outside drawing size of the block texture
    pos = intersect ? newpos : pos;
    return intersect;
}

bool IntersectVarious(int blockID, inout vec3 pos, vec3 dir, out vec3 plane) {
    if (blockID >= 192 && blockID <= 193) {  // nether portal
        return IntersectF(blockID, pos, dir, plane);
    } else if (blockID >= 1000 && blockID <= 1023) {  // stairs
        return IntersectStair(blockID, pos, dir, plane);
    } else {
        return IntersectAABB(pos, dir, unpack_AABB(getBounds(blockID)), plane);
    }
}

bool SimpleIntersectVarious(int blockID, vec3 pos, vec3 dir) {
    if (blockID >= 192 && blockID <= 193) {  // nether portal
        vec3 plane;
        return IntersectF(blockID, pos, dir, plane);
    } else if (blockID >= 1000 && blockID <= 1023) {  // stairs
        return SimpleIntersectStair(blockID, pos, dir);
    } else {
        return SimpleIntersectAABB(pos, dir, unpack_AABB(getBounds(blockID)));
    }
}
