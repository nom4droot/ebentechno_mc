layout (local_size_x = 32, local_size_y = 32) in;
const vec2 workGroupsRender = vec2(1.0, 1.0);

// declaration for colorimg1 is in Raybuffer.glsl

uniform vec2 viewSize;        // for Random.glsl
uniform int frameCounter;     // for Random.glsl
uniform bool accum;           // for Random.glsl
#define RAND_SEED uint(uint(gl_GlobalInvocationID.x) + uint(16384) * frameCounter)
#include "../../includes/Random.glsl"  // for Pathtracing.glsl
uniform vec3 cameraPosition;  // for Voxelization.glsl
uniform float far;            // for Voxelization.glsl
#include "../../includes/Voxelization.glsl"  // for Raybuffer.glsl

layout (r32ui) uniform uimage2D voxel_data_img;   // for Raybuffer.glsl
layout (r32ui) uniform uimage2D voxel_data_img2;  // for Raybuffer.glsl
layout (r32ui) uniform uimage2D colorimg3;        // for Raybuffer.glsl
#include "/includes/Raybuffer.glsl"  // for RAYBUFFER_MULT
uniform usampler2D colortex14;  // for Pathtracing.glsl
uniform vec3 sunDirection;      // for Pathtracing.glsl
uniform float sunAngle;         // for Pathtracing.glsl
#include "/includes/Pathtracing.glsl"  // for AMBIENT_RAYS,SUNLIGHT_RAYS,SPECULAR_RAYS

uniform float viewWidth, viewHeight;

void main() {
    ivec2 coord = ivec2(gl_GlobalInvocationID.xy);
    int vw = int(viewWidth);
    int vh = int(viewHeight);
    
    // initialize Ray Buffer in colortex1
    imageStore(raybuffer_img, coord, vec4(0.0));
    imageStore(raybuffer_img, ivec2(     coord.x, vh + coord.y), vec4(0.0));
    imageStore(raybuffer_img, ivec2(vw + coord.x,      coord.y), vec4(0.0));
    imageStore(raybuffer_img, ivec2(vw + coord.x, vh + coord.y), vec4(0.0));
    #if (defined SUNLIGHT_RAYS) && (defined AMBIENT_RAYS) && (defined SPECULAR_RAYS)
        #if (RAYBUFFER_MULT == 1)
            //Case: size.buffer.colortex1=2.0 3.0 (viewWidth*2.0, viewHeight*3.0)
            imageStore(raybuffer_img, ivec2(         coord.x, vh * 2 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(    vw + coord.x, vh * 2 + coord.y), vec4(0.0));
        #elif (RAYBUFFER_MULT == 2)
            //Case: size.buffer.colortex1=4.0 3.0 (viewWidth*4.0, viewHeight*3.0)
            imageStore(raybuffer_img, ivec2(         coord.x, vh * 2 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(    vw + coord.x, vh * 2 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x,          coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x,     vh + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x, vh * 2 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x,          coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x,     vh + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x, vh * 2 + coord.y), vec4(0.0));
        #elif (RAYBUFFER_MULT == 4)
            //Case: size.buffer.colortex1=4.0 5.0 (viewWidth*4.0, viewHeight*5.0)
            imageStore(raybuffer_img, ivec2(         coord.x, vh * 2 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(         coord.x, vh * 3 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(         coord.x, vh * 4 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(    vw + coord.x, vh * 2 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(    vw + coord.x, vh * 3 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(    vw + coord.x, vh * 4 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x,          coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x,     vh + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x, vh * 2 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x, vh * 3 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x, vh * 4 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x,          coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x,     vh + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x, vh * 2 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x, vh * 3 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x, vh * 4 + coord.y), vec4(0.0));
        #endif
    #else
        #if (RAYBUFFER_MULT == 1)
            //Case: size.buffer.colortex1=2.0 2.0 (viewWidth*2.0, viewHeight*2.0)

        #elif (RAYBUFFER_MULT == 2)
            //Case: ize.buffer.colortex1=4.0 2.0 (viewWidth*4.0, viewHeight*2.0)
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x,          coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x,     vh + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x,          coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x,     vh + coord.y), vec4(0.0));
        #elif (RAYBUFFER_MULT == 4)
            //Case: size.buffer.colortex1=4.0 4.0 (viewWidth*4.0, viewHeight*4.0)
            imageStore(raybuffer_img, ivec2(         coord.x, vh * 2 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(         coord.x, vh * 3 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(    vw + coord.x, vh * 2 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(    vw + coord.x, vh * 3 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x,          coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x,     vh + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x, vh * 2 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 2 + coord.x, vh * 3 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x,          coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x,     vh + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x, vh * 2 + coord.y), vec4(0.0));
            imageStore(raybuffer_img, ivec2(vw * 3 + coord.x, vh * 3 + coord.y), vec4(0.0));
        #endif
    #endif
}
