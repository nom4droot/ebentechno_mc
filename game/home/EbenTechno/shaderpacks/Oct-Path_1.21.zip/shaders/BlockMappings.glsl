#if (defined gbuffers_entities) || (defined gbuffers_textured)
	#define backport_id(ID) 0
#else
	#if MC_VERSION >= 11300
		#define backport_id(ID) ((ID) == -1 ? 1 : (ID))
	#else
		#define backport_id(ID) (ID)
	#endif
#endif


#define UNHANDLED_BLOCKS 1  // [0 1 2]

bool is_entity(int ID)        { return ID == 0; }
bool is_simple_voxel(int ID)  { return ID == 2; }
//bool is_leaves_type(int ID)   { return (ID % 64) == 3; }
//bool is_glass_type(int ID)    { return (ID % 64) == 4; }
//bool is_emissive(int ID)      { return (ID & 64) > 0 && (ID != 250); }
bool is_emissive(int ID)      { return ID >= 64 && ID <= 193; }
float emitterLevel(int ID) {  // emitter brightness level {0.25, 0.50, 0.75, 1.00}
	ID = ID <= 127 ? (ID - 64) : (ID - 128);
	int lv = (ID / 16) + 1;
	lv = (ID >= 192 && ID <= 193) ? 3 : lv;
	return float(lv) / 4.0;
}
bool is_coloring(int ID)      { return ID == 65 || ID == 80 || ID == 97 || ID == 113 || ID == 114; }
bool is_translucent(int ID)   { return ID >= 196 && ID <= 199; }
bool is_water(int ID)         { return ID == 200; }
//bool is_backface_type(int ID) { return ID == 3 || ID == 4; }
//bool is_sapling(int ID)       { return ID == 5; }
//bool is_tallgrass(int ID)     { return ID == 7; }
//bool is_sub_voxel(int ID)     { return ID >= 3 && ID <= 21; }
bool is_sub_voxel(int ID)     { return (ID >= 3 && ID <= 63) || (ID >= 128 && ID <= 193) || (ID >= 1000 && ID <= 1999); }
//bool is_iron_block(int ID)     { return ID == 22; }
bool is_iron_block(int ID)    { return ID == 201; }
bool is_trapdoor_weird(int ID) { return ID >= 37 && ID <= 42; }
bool is_trapdoor(int ID)       { return ID >= 31 && ID <= 42; }
bool is_burning(int ID)       { return ID == 176 || ID == 160 || ID == 144 || ID == 114; }  // torch types, furnace types

/*
bool is_voxelized(int ID) { return
	is_sub_voxel(ID) ||
	is_iron_block(ID) ||
	(!is_entity(ID))
	&& (ID != 1)
	&& (ID < 5 || ID == 8 || ID == 66 || ID >= 85 || ID == 75)
	&& (ID != 200)
	&& (ID != 250)
	|| is_glass_type(ID);
}
*/
bool is_voxelized(int ID) { return
	is_simple_voxel(ID) ||
	is_sub_voxel(ID) ||
	(ID >= 64 && ID <= 127) ||
	is_translucent(ID) ||
	is_iron_block(ID);
}
