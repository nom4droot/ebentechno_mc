#include "../glsl_version.glsl"
#include "worldID.glsl"
#define deferred11
#define csh

#include "../programs/deferred/D11_InitBuf.glsl"
