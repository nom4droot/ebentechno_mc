#include "../glsl_version.glsl"
#include "worldID.glsl"
#define deferred0
#define csh

#include "../programs/deferred/D0_Raytracing.glsl"
