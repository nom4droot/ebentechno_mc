#include "../glsl_version.glsl"
#include "worldID.glsl"
#define gbuffers_terrain
#define fsh

#include "../programs/gbuffers/gbuffers_raster.glsl"
