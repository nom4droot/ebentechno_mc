#include "../glsl_version.glsl"
#include "worldID.glsl"
#define deferred2
#define fsh

#include "../programs/deferred/D2_Combine.glsl"
