#include "../glsl_version.glsl"
#include "worldID.glsl"
#define gbuffers_weather
#define fsh

uniform float far;
uniform vec3 cameraPosition;
uniform vec2 viewSize;

#include "/BlockMappings.glsl"
#include "/includes/Voxelization.glsl"

/**********************************************************************/
uniform sampler2D tex;
uniform usampler2D normals;
uniform sampler2D specular;
uniform sampler2D noisetex;

uniform sampler2D colortex11;

#undef atlas_tex_n
#define atlas_tex_n normals

uniform int frameCounter;
uniform float frameTimeCounter;

uniform mat4 gbufferModelView;
uniform mat4 gbufferProjection;

ivec2 atlasSize = ivec2(textureSize(tex, 0).xy);

in mat3 _tanMat;
in vec4 _vertexColor;
in vec3 _worldPos;
in vec3 _viewPos;
in vec3 _voxelPos;
in vec2 _texcoord;
flat in vec2 _cornerTexcoord;
//flat in ivec2 _spriteSize;
//flat in int _blockID;
//flat in ivec3 ivoxelPos;
flat in uint packed_tex_coord;
flat in uint packedVoxelData;

#include "/includes/debug.glsl"

#include "/lib/Pack.glsl"

//#include "/includes/Parallax.glsl"

/* RENDERTARGETS:11 */

layout (location = 0) out vec4 colortex11Write;

void main() {
    vec2 tCoord = _texcoord;
    
    vec4 diffuse = texture2D(tex, tCoord);
    
    float rain_a = diffuse.a * _vertexColor.a;
    if (rain_a < 0.6) discard;  // (0.0 <) heavy rain <- 0.3 -> light rain
    
    ivec2 fragCoord = ivec2(gl_FragCoord.xy);
    vec4 ct11 = texelFetch(colortex11, fragCoord, 0);
    ct11.a = 1.0;
    colortex11Write = ct11;
    
    exit();
}
