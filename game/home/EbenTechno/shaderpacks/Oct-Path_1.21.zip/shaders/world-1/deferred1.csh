#include "../glsl_version.glsl"
#include "worldID.glsl"
#define deferred1
#define csh

#include "../programs/deferred/D1_Ray1.glsl"
