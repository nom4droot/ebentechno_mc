#include "../glsl_version.glsl"
#include "worldID.glsl"
#define gbuffers_weather
#define vsh

uniform float far;
uniform vec3 cameraPosition;
uniform vec2 viewSize;

#include "/BlockMappings.glsl"
#include "/includes/Voxelization.glsl"

/**********************************************************************/
attribute vec4 at_tangent;
attribute vec3 mc_Entity;
attribute vec2 mc_midTexCoord;

uniform sampler2D tex;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;

uniform vec3 previousCameraPosition;
ivec2 atlasSize = ivec2(textureSize(tex, 0).xy);

uniform float frameTimeCounter;
uniform int frameCounter;
uniform bool accum;

#include "/includes/Random.glsl"


#define tanMat _tanMat
#define vertexColor _vertexColor
#define worldPos _worldPos
#define viewPos _viewPos
#define voxelPos _voxelPos
#define midTexcoord _midTexcoord
#define cornerTexcoord _cornerTexcoord
#define texcoord _texcoord
//#define spriteSize _spriteSize
//#define blockID _blockID

out mat3 tanMat;
out vec4 vertexColor;
out vec3 worldPos;
out vec3 viewPos;
out vec3 voxelPos;
flat out vec2 midTexcoord;
flat out vec2 cornerTexcoord;
out vec2 texcoord;
//flat out ivec2 spriteSize;
//flat out int blockID;
//flat out ivec3 ivoxelPos;
flat out uint packed_tex_coord;
flat out uint packedVoxelData;

// Returns the tangent to world space matrix
mat3 GetTangentMat() {
    // World-space normal matrix
    mat3 normal_mat = mat3(gbufferModelViewInverse) * gl_NormalMatrix;
    
    vec3 tangent  = normalize(normal_mat * at_tangent.xyz);
    vec3 normal   = normalize(normal_mat *  gl_Normal.xyz);
    vec3 binormal = normalize(cross(tangent, normal));
    
    return mat3(tangent, binormal, normal);
}

void main() {
    vertexColor    = gl_Color;
    texcoord       = gl_MultiTexCoord0.xy;
    tanMat         = GetTangentMat();
    //blockID        = backport_id(int(mc_Entity.x)) % 256;
    midTexcoord    = mc_midTexCoord;
    cornerTexcoord = mc_midTexCoord.xy - abs(mc_midTexCoord.xy - texcoord);
    vec2 texDirection = sign(texcoord - mc_midTexCoord)*vec2(1,sign(at_tangent.w));
    worldPos    = (gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex).xyz;
    vec3 triCentroid = worldPos.xyz - (tanMat * vec3(texDirection,0.0)) - tanMat[2] / 32.0;
    triCentroid = mix(worldPos, triCentroid, 0.5);
    voxelPos    = WorldToVoxelSpace(mix(worldPos, triCentroid, exp2(-11))) + tanMat[2] * exp2(-11);
    // worldPos = mix(worldPos, triCentroid, -0.2);
    viewPos     = (gbufferModelView * vec4(worldPos, 1.0)).xyz;
    
    gl_Position = gbufferProjection * vec4(viewPos, 1.0);
    gl_Position.xy += TAAHash() * gl_Position.w;
    
}
