#include "../glsl_version.glsl"
#include "worldID.glsl"
#define gbuffers_terrain
#define vsh

#include "../programs/gbuffers/gbuffers_raster.glsl"
