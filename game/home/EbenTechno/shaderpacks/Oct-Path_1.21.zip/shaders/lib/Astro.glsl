/*
fBm function for pattern on the moon from Shadertoy "20211223 5 types of noise" by kamonumber ( https://www.shadertoy.com/view/slKXRR )
License of this module: CC BY-NC-SA 3.0 ( https://creativecommons.org/licenses/by-nc-sa/3.0/ )
*/

vec2 rand(vec2 uv) {  // Create a sine wave by referencing uv, then scale it up and use fract() to get only the decimal part
    vec2 random = vec2(fract(sin(dot(uv,vec2(15.15, 154.15)))*10455.487))*2.0 - 1.0;
    return random;
}

float perlin(vec2 uv) {  // Perlin noise
    //float r = 10.;
    //uv*=vec2(r,r);
    vec2 i = floor(uv);
    vec2 f = fract(uv);
    vec2 u = f*f*3.0 - f*f*f*2.0;
    
    vec2 g00 = (rand(i));
    vec2 g01 = (rand(i + vec2(0., 1.)));
    vec2 g10 = (rand(i + vec2(1., 0.)));
    vec2 g11 = (rand(i + vec2(1., 1.)));
    
    vec2 d00 = (f);
    vec2 d01 = (f - vec2(0., 1.));
    vec2 d10 = (f - vec2(1., 0.));
    vec2 d11 = (f - vec2(1., 1.));
    
    float m00 = dot(g00, d00);
    float m01 = dot(g01, d01);
    float m10 = dot(g10, d10);
    float m11 = dot(g11, d11);
    
    float result = mix(mix(m00, m10, u.x), mix(m01, m11, u.x), u.y);
    return result + 0.5;
}

float fbm(vec2 uv) {  // fBm(Fractional Brownian Motion): making Perlin noise finer by reducing uv, and superimposing it
    float r = 10.;
    uv *= vec2(r, r);
    float f = 0.0;
    f +=    0.5 * perlin(uv);  uv *= 2.0;
    f +=   0.25 * perlin(uv);  uv *= 2.0;
    f +=  0.125 * perlin(uv);  uv *= 2.0;
    f += 0.0725 * perlin(uv);  uv *= 2.0;
    return f;
}
