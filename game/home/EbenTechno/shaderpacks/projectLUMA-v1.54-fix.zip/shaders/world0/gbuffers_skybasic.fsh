#version 120

#include "lib/HDR.glsl"

#define TEMPERATURE 1.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

varying vec4 position;
varying float stars;

uniform sampler2D gaux4;

uniform int worldTime;

uniform float rainStrength;
uniform float screenBrightness;
uniform float nightVision;

#include "lib/timeArray.glsl"
#include "lib/common/sky.glsl"

void main() {

  vec3 sky = getSkyTextureFromSequence(position.xyz);
  vec3 fog = sky;

  // Fake subsurface scattering for the HDR effect
  sky += pow(dot(sky, vec3(0.3333)), 12.0) * 6.0 * (1.0 - rainStrength);

/* DRAWBUFFERS:061 */

  gl_FragData[0] = vec4(sky / MAX_COLOR_RANGE, 1.0 - stars);
  gl_FragData[1] = vec4(fog / MAX_COLOR_RANGE, 1.0 - stars);
  gl_FragData[2] = vec4(0.0, 0.0, 0.0, 1.0);

}
