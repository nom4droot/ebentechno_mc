float luma(vec3 clr) {
	return dot(clr, vec3(0.3333));
}