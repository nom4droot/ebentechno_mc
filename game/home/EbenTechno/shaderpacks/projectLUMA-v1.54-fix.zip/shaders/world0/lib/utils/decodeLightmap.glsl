vec2 decodeLightmap(float a) {
    int bf = int(a * 65535.0);
    return vec2(bf % 256, bf >> 8) / 255.0;
}