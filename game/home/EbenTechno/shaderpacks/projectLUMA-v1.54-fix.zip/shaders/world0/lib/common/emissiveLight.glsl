vec3 emissiveLight(vec3 clr, vec3 originalClr, bool emissive) {

	const float cover		= 0.3;

	float brightness = clamp(normal.a, 0.29, 0.39) - 0.29;

	//if (forHand) emissive = emissiveHandlight;
	if (brightness > 0.0) clr *= 1.0 + max(luma(originalClr.rgb) - cover, 0.0) * 12.0 * (1.0 + brightness * 10.0);

	return clr;

}
